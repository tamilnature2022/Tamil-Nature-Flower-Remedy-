plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tamilnature.shanmugam"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tamilnature.shanmugam"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
